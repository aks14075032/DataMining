from django.shortcuts import render
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect, HttpResponse
from django.db import connection
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.models import User
from .forms import *
import datetime

#login for all three type of user
def user_login(request, user):
    if request.method == 'POST':
        username = request.POST.get('username') #fetch from login page
        password = request.POST.get('password')

        user_auth = authenticate(username=username, password=password) #authenticate with auth_user in database

        #if true
        if user_auth:
            if user == 'patient':
                #check with patient table if user is patient or not
                with connection.cursor() as cursor:
                    cursor.execute("SELECT P_ID,Password FROM Patients WHERE P_ID=%s AND Password=%s", [username,password])
                    user1 = cursor.fetchone()

                #if yes then login
                if user1:
                    if user_auth.is_active:
                        login(request, user_auth)
                        #login(request, user)
                        return HttpResponseRedirect('/ak/appointment/')       #after login send user to this page
                    else:
                        return render(request,'ak/login.html',{'error_message':'Your accout is disabled'})
                else:
                    print "Invalid login details: {0}, {1}".format(username, password)
                    return render(request,'ak/login.html',{'error_message':'Invalid login details supplied:Not a patient'})

            elif user == 'admin':
                #check with admin table if user is admin or not
                with connection.cursor() as cursor:
                    cursor.execute("SELECT AD_ID,Password FROM Admin WHERE AD_ID=%s AND Password=%s", [username,password])
                    user1 = cursor.fetchone()


                if user1:
                    if user_auth.is_active:
                        login(request, user_auth)
                        return HttpResponseRedirect('/ak/d_regis/')
                    else:
                        return render(request,'ak/login.html',{'error_message':'Your accout is disabled'})
                else:
                    print "Invalid login details: {0}, {1}".format(username, password)
                    return render(request,'ak/login.html',{'error_message':'Invalid login details supplied:Not a admin'})

            #check with doctor table if user is doctor or not
            elif user == 'doctor':
                with connection.cursor() as cursor:
                    cursor.execute("SELECT Do_ID,Password FROM Doctor WHERE Do_ID=%s AND Password=%s", [username,password])
                    user1 = cursor.fetchone()


                if user1:
                    if user_auth.is_active:
                        login(request, user_auth)
                        return HttpResponseRedirect('/ak/my_app')
                    else:
                        return render(request,'ak/login.html',{'error_message':'Your accout is disabled'})
                else:
                    print "Invalid login details: {0}, {1}".format(username, password)
                    return render(request,'ak/login.html',{'error_message':'Invalid login details supplied:Not a doctor'})

        else:
            # Bad login details were provided. So we can't log the user in.
            print "Invalid login details: {0}, {1}".format(username, password)
            return render(request,'ak/login.html',{'error_message':'Invalid login details supplied '})



    else:
        return render(request, 'ak/login.html', {})

#main page
def index(request):
	return render(request,'ak/index.html')

#used for registration of new patients by own
def register(request):
    registered = False
    if request.method == 'POST':
        #form = register(request.POST)
        #if form.is_valid():
            fn = request.POST.get('first_name')
            ls = request.POST.get('last_name')
            username = request.POST.get('username')
            password = request.POST.get('password')
            repassword = request.POST.get('repassword')
            contact = request.POST.get('Contact')
            city = request.POST.get('City')
            gender = request.POST.get('gender')
            dob = request.POST.get('dob')

            #print len(contact)
            #print contact[0]
            #check for valid date of birth
            if password == repassword:
                td = datetime.datetime.strptime(dob, '%Y-%m-%d')
                today = datetime.datetime.today()
                difference = today - td
                if difference.days >= 0 and difference.days <= 36500:          #to be patient age should be greater than 0 and less than 100 years
                #check if username already exists
                    with connection.cursor() as cursor:
                        cursor.execute("SELECT username FROM auth_user WHERE username=%s", [username])
                        chk = cursor.fetchall()

                    #if username already exists then error
                    if chk:
                        return render(request,'ak/register.html',{'error_message':'Username already exists '})
                    
                    else:
                        #check for mobile number if true then insert data into patients
                        if len(contact)==10 and contact[0]=='9' or contact[0]=='8' or contact[0] == '7':
                            if contact[1] == '0' or contact[1] == '1' or contact[1] == '2' or contact[1] == '3' or contact[1] == '4'  or contact[1] == '5' or contact[1] == '6' or contact[1] == '7' or contact[1] == '8' or contact[1] == '9':
                                if contact[2] == '0' or contact[2] == '1' or contact[2] == '2' or contact[2] == '3' or contact[2] == '4' or contact[2] == '5' or contact[2] == '6' or contact[2] == '7' or contact[2] == '8' or contact[2] == '9':
                                    if contact[3] == '0' or contact[3] == '1' or contact[3] == '2' or contact[3] == '3' or contact[3] == '4' or contact[3] == '5' or contact[3] == '6' or contact[3] == '7' or contact[3] == '8' or contact[3] == '9' :
                                        if contact[4] == '0' or contact[4] == '1' or contact[4] == '2' or contact[4] == '3' or contact[4] == '4' or contact[4] == '5' or contact[4] == '6' or contact[4] == '7' or contact[4] == '8' or contact[4] == '9' :
                                            if contact[5] == '0' or contact[5] == '1' or contact[5] == '2' or contact[5] == '3' or contact[5] == '4' or contact[5] == '5' or contact[5] == '6' or contact[5] == '7' or contact[5] == '8' or contact[5] == '9' :
                                                if contact[6] == '0' or contact[6] == '1' or contact[6] == '2' or contact[6] == '3' or contact[6] == '4' or contact[6] == '5' or contact[6] == '6' or contact[6] == '7' or contact[6] == '8' or contact[6] == '9' :
                                                    if contact[7] == '0' or contact[7] == '1' or contact[7] == '2' or contact[7] == '3' or contact[7] == '4' or contact[7] == '5' or contact[7] == '6' or contact[7] == '7' or contact[7] == '8' or contact[7] == '9' :
                                                        if contact[8] == '0' or contact[8] == '1' or contact[8] == '2' or contact[8] == '3' or contact[8] == '4' or contact[8] == '5' or contact[8] == '6' or contact[8] == '7' or contact[8] == '8' or contact[8] == '9' :
                                                            if contact[9] == '0' or contact[9] == '1' or contact[9] == '2' or contact[9] == '3' or contact[9] == '4' or contact[9] == '5' or contact[9] == '6' or contact[9] == '7' or contact[9] == '8' or contact[9] == '9' :

                                                                with connection.cursor() as cursor:
                                                                    cursor.execute("SELECT phone_number FROM Patients WHERE phone_number=%s", [contact])
                                                                    chk = cursor.fetchall()

                                                                if not chk:
                                                                    with connection.cursor() as cursor:
                                                                        cursor.execute("INSERT INTO Patients(P_ID,Password,first_name,last_name,city,phone_number,GENDER,d_o_b) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)", [username,password,fn,ls,city,contact,gender,dob])
                                                                        user1 = cursor.fetchone()

                                                                    User.objects.create_user(username,None,password)           #insert into auth user
                                                            #with connection.cursor() as cursor:
                                                             #   cursor.execute("INSERT INTO auth_user(username,password) VALUES(%s,%s)", [username,password])
                                                              #  user1 = cursor.fetchone()

                                                                    registered = True
                                                                else:
                                                                    return render(request,'ak/register.html',{'error_message1':'Mobile Number already used'})
                                                            else:
                                                                return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                                        else:
                                                            return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                                    else:
                                                        return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                                else:
                                                    return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                            else:
                                                return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                        else:
                                            return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                    else:
                                        return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                                else:
                                    return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                            else:
                                return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})
                        else:
                            return render(request,'ak/register.html',{'error_message1':'Invalid Mobile Number'})

                else:
                    return render(request,'ak/register.html',{'error_message3':'Enter Valid Date of birth'})
            else:
                return render(request,'ak/register.html',{'error_message37':'Password did not match'})

    return render(request,
            'ak/register.html',
            {'registered': registered } )

#Book an appointment by patients
@login_required
def appointment(request):
    done = False        #used for appointment confimation
    fee=0               #doctor fee to be paid
    user_type = ""
    if request.method == 'POST':
        aid = request.POST.get('aid')
        did = request.POST.get('did')
        subject = request.POST.get('subject')
        time = request.POST.get('time')
        date = request.POST.get('date')

        #check for appointment id 
        with connection.cursor() as cursor:
            cursor.execute("SELECT APP_ID FROM appointment WHERE APP_ID=%s", [aid])
            userk = cursor.fetchone()

        #if same appointment id does not exists 
        if not userk:
            #check for enterd doctor id is correct
            with connection.cursor() as cursor:
                cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s", [did])
                user = cursor.fetchone()
                #if doctor id matched
                if user:
                    #check if same time,date and doctor id has not been booked previously 
                    with connection.cursor() as cursor:
                        cursor.execute("SELECT Date FROM appointment WHERE Do_ID=%s AND Date=%s AND time=%s", [did,date,time])
                        chk = cursor.fetchone()

                    #if already booked then erroe 
                    if chk:
                        return render(request,'ak/appointment.html',{'error_message1':'Slot already booked take another slot'})
                    
                    #confirm the appointment
                    else:

#                        now = datetime.date.today()
 #                       print now
  #                      print date
                        #check for valid appointment date
                        td = datetime.datetime.strptime(date, '%Y-%m-%d')
                        today = datetime.datetime.today()
                        difference = td - today
                        if difference.days > 0:
                            #insert into appointment
                            if difference.days < 62:
                                with connection.cursor() as cursor:
                                    done = True
                                    cursor.execute("INSERT INTO appointment(APP_ID,Do_ID,P_ID,Subject,time,Date) VALUES(%s,%s,%s,%s,%s,%s)", [aid,did,request.user,subject,time,date])
                                    user = cursor.fetchone()

                                #pay the fee for doctor depend on department
                                with connection.cursor() as cursor:
                                    cursor.execute("SELECT Department FROM Doctor WHERE Do_ID=%s", [did])
                                    user = cursor.fetchone()

                                if user[0]=='Bones':
                                    fee=400
                                elif user[0]=='General Medicine':
                                    fee=300
                                elif user[0]=='Heart':
                                    fee=500
                                elif user[0]=='Surgeon':
                                    fee=600

                                with connection.cursor() as cursor:
                                    cursor.execute("INSERT INTO bill(APP_ID,Doctor_charges)VALUES(%s,%s)", [aid,fee])
                                    user = cursor.fetchone()

                            else:
                                return render(request,'ak/appointment.html',{'error_message3':'Enter Valid Date  booking allowed with in two months'})
                        
                        else:
                            return render(request,'ak/appointment.html',{'error_message3':'Enter Valid Date cannot book in previous dates'})


                else:
                    return render(request,'ak/appointment.html',{'error_message':'Invalid Doctor ID'})

        else:
            return render(request,'ak/appointment.html',{'error_message2':'Appointment ID already used'})
    
    #type of user who is login either patient doctor or admin
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

        if user3:
            user_type='patient'
        else:
            with connection.cursor() as cursor:
                cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
                user4 = cursor.fetchone()

            if user4:
                user_type='doctor'
            else:
                user_type='admin'
                
    return render(request,'ak/appointment.html',{'done': done,'user_type':user_type})


#registration of doctor by admin
@login_required
def d_regis(request):
    registered = False    #used for  confimation
    user_type=""
    if request.method == 'POST':
        fn = request.POST.get('first_name')
        ls = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')
        contact = request.POST.get('Contact')
        city = request.POST.get('City')
        gender = request.POST.get('gender')
        dept =   request.POST.get('department')
        dob = request.POST.get('dob')

        #check for valid date of birth 
        if password == repassword:
            td = datetime.datetime.strptime(dob, '%Y-%m-%d')
            today = datetime.datetime.today()
            difference = today - td
            if difference.days >= 8030 and difference.days <= 25550:          #to be doctor age should be greater than 22 and less than 70 years
                #check if username already exits
                with connection.cursor() as cursor:
                    cursor.execute("SELECT username FROM auth_user WHERE username=%s", [username])
                    chk = cursor.fetchall()

                #if yes then error
                if chk:
                    return render(request,'ak/d_regis.html',{'error_message':'Username already exits '})
                
                #if no then confirm registration 
                else:
                    if len(contact)==10 and contact[0]=='9' or contact[0]=='8' or contact[0] == '7':
                        if contact[1] == '0' or contact[1] == '1' or contact[1] == '2' or contact[1] == '3' or contact[1] == '4'  or contact[1] == '5' or contact[1] == '6' or contact[1] == '7' or contact[1] == '8' or contact[1] == '9':
                            if contact[2] == '0' or contact[2] == '1' or contact[2] == '2' or contact[2] == '3' or contact[2] == '4' or contact[2] == '5' or contact[2] == '6' or contact[2] == '7' or contact[2] == '8' or contact[2] == '9':
                                if contact[3] == '0' or contact[3] == '1' or contact[3] == '2' or contact[3] == '3' or contact[3] == '4' or contact[3] == '5' or contact[3] == '6' or contact[3] == '7' or contact[3] == '8' or contact[3] == '9' :
                                    if contact[4] == '0' or contact[4] == '1' or contact[4] == '2' or contact[4] == '3' or contact[4] == '4' or contact[4] == '5' or contact[4] == '6' or contact[4] == '7' or contact[4] == '8' or contact[4] == '9' :
                                        if contact[5] == '0' or contact[5] == '1' or contact[5] == '2' or contact[5] == '3' or contact[5] == '4' or contact[5] == '5' or contact[5] == '6' or contact[5] == '7' or contact[5] == '8' or contact[5] == '9' :
                                            if contact[6] == '0' or contact[6] == '1' or contact[6] == '2' or contact[6] == '3' or contact[6] == '4' or contact[6] == '5' or contact[6] == '6' or contact[6] == '7' or contact[6] == '8' or contact[6] == '9' :
                                                if contact[7] == '0' or contact[7] == '1' or contact[7] == '2' or contact[7] == '3' or contact[7] == '4' or contact[7] == '5' or contact[7] == '6' or contact[7] == '7' or contact[7] == '8' or contact[7] == '9' :
                                                    if contact[8] == '0' or contact[8] == '1' or contact[8] == '2' or contact[8] == '3' or contact[8] == '4' or contact[8] == '5' or contact[8] == '6' or contact[8] == '7' or contact[8] == '8' or contact[8] == '9' :
                                                        if contact[9] == '0' or contact[9] == '1' or contact[9] == '2' or contact[9] == '3' or contact[9] == '4' or contact[9] == '5' or contact[9] == '6' or contact[9] == '7' or contact[9] == '8' or contact[9] == '9' :

                                                            print contact[0]
                                                            with connection.cursor() as cursor:
                                                                cursor.execute("SELECT phone_number FROM Doctor WHERE phone_number=%s", [contact])
                                                                chk = cursor.fetchall()
                                                            if not chk:
                                                                with connection.cursor() as cursor:
                                                                    cursor.execute("INSERT INTO Doctor(Do_ID,Password,first_name,last_name,city,phone_number,GENDER,Department,AD_ID,date_of_birth) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", [username,password,fn,ls,city,contact,gender,dept,str(request.user),dob])
                                                                    user1 = cursor.fetchone()
                                                                User.objects.create_user(username,None,password)
                                                                #with connection.cursor() as cursor:
                                                                 #   cursor.execute("INSERT INTO auth_user(username,password) VALUES(%s,%s)", [username,password])
                                                                  #  user1 = cursor.fetchone()

                                                                registered = True
                                                            else:
                                                                return render(request,'ak/d_regis.html',{'error_message11':'Mobile Number already used'})
                                                        else:
                                                            return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                                                    else:
                                                        return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                                                else:
                                                    return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                                            else:
                                                return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                                        else:
                                            return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                                    else:
                                        return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                                else:
                                    return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                            else:
                                return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                        else:
                            return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
                    else:
                        return render(request,'ak/d_regis.html',{'error_message1':'Invalid Mobile Number'})
            else:
                return render(request,'ak/d_regis.html',{'error_message3':'Enter Valid Date of birth'})
        else:
            return render(request,'ak/d_regis.html',{'error_message37':'Password did not match'})

        #return HttpResponse("Thank You")

    #check forvtype of user who is login
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'


    return render(request,
            'ak/d_regis.html',
            {'registered': registered,'user_type':user_type} )


#to get feedback from patient about doctor and hospital
@login_required
def feedback(request):
    registered=False
    user_type=""
    if request.method == 'POST':
        aid = request.POST.get('app_id')
        subject = request.POST.get('subject')
        
        #check for patient id to give feeback user should be patient
        with connection.cursor() as cursor:
            cursor.execute("SELECT P_ID FROM appointment WHERE P_ID=%s ", [str(request.user)])
            chk = cursor.fetchone()

        #check for appointment id
        if chk:
            with connection.cursor() as cursor:
                cursor.execute("SELECT APP_ID FROM appointment WHERE APP_ID=%s ", [aid])
                user = cursor.fetchone()

            #if found then
            if user:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT Date FROM appointment WHERE APP_ID=%s ", [aid])
                    date = cursor.fetchone()
                print type(date[0])
                #td = datetime.datetime.strptime(date[0], '%Y-%m-%d')
                dt1 = datetime.datetime.today()
                dt2 = datetime.datetime.combine(date[0], datetime.time(0, 0))
                #difference = today - date[0]
                if dt1 > dt2:
                    registered=True
                    with connection.cursor() as cursor:
                        cursor.execute("INSERT INTO feedback(APP_ID,Subject) VALUES(%s,%s)", [aid,subject])
                        user = cursor.fetchone()
                
                else:
                    return render(request,'ak/feedback.html',{'error_message':'Appointment is not done you can not give feedback'})
            #error
            else:
                return render(request,'ak/feedback.html',{'error_message':'Invalid Appointment ID'})
        else:
            return render(request,'ak/feedback.html',{'error_message1':'It is not your appointment ID'})

    #type of user who is login
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'

    return render(request,'ak/feedback.html',{'registered': registered,'user_type':user_type})

#cancel appointment can be done by doctor,patients 
@login_required
def cancel(request):
    user_type=""
    registered=False
    if request.method == 'POST':
        aid = request.POST.get('app_id')         #get appointment id 
        
        #check for appointment id correct or not
        with connection.cursor() as cursor:
            cursor.execute("SELECT P_ID FROM appointment WHERE APP_ID=%s", [aid])
            user1 = cursor.fetchone()

        #if correct then should be either patient or doctor
        if user1:
            #check if user is deleting his own appointment or not and user is patient
            if user1[0] == str(request.user):
                registered=True
                with connection.cursor() as cursor:
                    cursor.execute("DELETE FROM appointment WHERE APP_ID=%s",[aid])
                    user2 = cursor.fetchone()

            #check if user is deleting his own appointment or not and user is doctor
            else:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT Do_ID FROM appointment WHERE APP_ID=%s", [aid])
                    userd = cursor.fetchone()
                    if userd[0] == str(request.user):
                        registered=True
                        with connection.cursor() as cursor:
                            cursor.execute("DELETE FROM appointment WHERE APP_ID=%s",[aid])
                            userm = cursor.fetchone()
                    
                    #if not deleting own appointment
                    else:
                        #print request.user
                        return render(request,'ak/capp.html',{'error_message':'You are not allowd to delete others appointment'})

        #invalid appointment id
        else:
            return render(request,'ak/capp.html',{'error_message2':'Invalid Appointment ID'})

    #check for type of user
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'


    return render(request,'ak/capp.html',{'registered': registered,'user_type':user_type})


#remove patient or doctor by admin
@login_required
def remove(request):
    user_type=""
    registered=False
    if request.method == 'POST':
        mid = request.POST.get('id')     #get id of user to be deleted

        #check in auth_user table
        with connection.cursor() as cursor:
            cursor.execute("SELECT username FROM auth_user WHERE username=%s", [mid])
            userk = cursor.fetchone()

        #if found in auth_user
        if userk:

            #delete from auth_user
            with connection.cursor() as cursor:
                    cursor.execute("DELETE FROM auth_user WHERE username=%s",[mid])
                    user2 = cursor.fetchone()

            #check for type of user
            with connection.cursor() as cursor:
                cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s", [mid])
                user1 = cursor.fetchone()

            #if user is patient then delete user
            if user1:
                registered=True
                with connection.cursor() as cursor:
                    cursor.execute("DELETE FROM Patients WHERE P_ID=%s",[mid])
                    user2 = cursor.fetchone()

            #if user is doctor delete from doctor table
            else:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s", [mid])
                    userd = cursor.fetchone()
                if userd:
                    registered=True
                    with connection.cursor() as cursor:
                        cursor.execute("DELETE FROM Doctor WHERE Do_ID=%s",[mid])
                        userm = cursor.fetchone()
                else:
                    #print request.user

                    return render(request,'ak/remove.html',{'error_message':'Invalid  ID'})
        else:
            return render(request,'ak/remove.html',{'error_message':'Invalid  ID'})

    #find type of user who is login
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'


    return render(request,'ak/remove.html',{'registered': registered,'user_type':user_type})

#see all the appointment a patient or doctor has
@login_required
def my_app(request):
    user_type=""

    #show all appointments to patient if logged in user is patient
    with connection.cursor() as cursor:
        cursor.execute("SELECT appointment.APP_ID,Doctor.first_name,appointment.time,appointment.Date FROM appointment,Doctor WHERE appointment.Do_ID=Doctor.Do_ID  AND P_ID=%s", [request.user])
        row = cursor.fetchall() 

    #show all appointments to doctor if logged in user is doctor
    if not row:
        with connection.cursor() as cursor:
            cursor.execute("SELECT appointment.APP_ID,Patients.first_name,appointment.time,appointment.Date FROM appointment,Patients WHERE appointment.P_ID=Patients.P_ID  AND Do_ID=%s", [request.user])
            row = cursor.fetchall() 

    #type of user who is logged in
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'
    return render(request,'ak/my_app.html',{'row': row,'user_type':user_type})   


#see the own profile by doctor and patient
@login_required
def my_profile(request):
    updated = False
    user_type=""
    #show user profile  to patient if logged in user is patient 
    with connection.cursor() as cursor:
        cursor.execute("SELECT first_name,last_name,city,state,phone_number FROM Patients WHERE P_ID=%s", [str(request.user)])
        row = cursor.fetchall() 

    #show user profile  to patient if logged in user is patient
    if not row:
        with connection.cursor() as cursor:
            cursor.execute("SELECT first_name,last_name,city,state,phone_number FROM Doctor WHERE Do_ID=%s", [str(request.user)])
            row = cursor.fetchall() 

    #check type of user who is logged in
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'


    #to update the profile of user or doctor
    if request.method == 'POST':
        fn = request.POST.get('first_name')
        ln = request.POST.get('last_name')
        city = request.POST.get('City')
        state = request.POST.get('state')
        contact = request.POST.get('Contact')

        #if user is patient update his profile
        if user_type == "patient":
            with connection.cursor() as cursor:
                cursor.execute("UPDATE Patients SET first_name = %s,last_name = %s,city = %s,state = %s,phone_number = %s WHERE P_ID=%s",[fn,ln,city,state,contact,str(request.user)])
                user1 = cursor.fetchone()
                updated = True

        #if user is doctor update his profile
        if user_type == "doctor":
            with connection.cursor() as cursor:
                cursor.execute("UPDATE Doctor SET first_name = %s,last_name = %s,city = %s,state = %s,phone_number = %s WHERE Do_ID=%s",[fn,ln,city,state,contact,str(request.user)])
                user1 = cursor.fetchone()
                updated = True

    
    return render(request,'ak/my_profile.html',{'row': row[0],'user_type':user_type,'updated': updated}) 


#feedback given by patient to doctor can be seen by admin 
@login_required
def s_feedback(request):
    user_type=""

    #check for type of user
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'    

    #see the feedback
    with connection.cursor() as cursor:
        cursor.execute("SELECT Doctor.first_name,Patients.first_name,feedback.Subject FROM Doctor,Patients,feedback,appointment WHERE appointment.APP_ID = feedback.APP_ID AND appointment.P_ID = Patients.P_ID AND appointment.Do_ID = Doctor.Do_ID")
        row = cursor.fetchall()
        

    return render(request,'ak/s_feedback.html',{'row': row,'user_type':user_type})

#list of doctors in hospital and there ids
@login_required
def doctor_list(request):
    user_type=""

    #type of user who is logged in
    with connection.cursor() as cursor:
        cursor.execute("SELECT P_ID FROM Patients WHERE P_ID=%s",[str(request.user)])
        user3 = cursor.fetchone()

    if user3:
        user_type='patient'
    else:
        with connection.cursor() as cursor:
            cursor.execute("SELECT Do_ID FROM Doctor WHERE Do_ID=%s",[str(request.user)])
            user4 = cursor.fetchone()

        if user4:
            user_type='doctor'
        else:
            user_type='admin'    

    #show doctors in hospital
    with connection.cursor() as cursor:
        cursor.execute("SELECT Do_ID,first_name,Department FROM Doctor")
        row = cursor.fetchall()
        

    return render(request,'ak/id_name.html',{'row': row,'user_type':user_type})

#used for logout of user
@login_required
def user_logout(request):
    # Since we know the user is logged in, we can now just log them out.
    logout(request)

    # Take the user back to the homepage.
    return HttpResponseRedirect('/ak/')

