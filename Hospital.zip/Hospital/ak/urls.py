from django.conf.urls import patterns, url
from . import views



urlpatterns = [
	url(r'^login/(?P<user>\w*)/$', views.user_login, name='login'),   #login page
	url(r'^appointment/$', views.appointment, name='appointment'),    #appointment page for booking appointment
	url(r'^capp/$', views.cancel, name='capp'),                       #cancel appointment page for cancelling booked appointment  
    url(r'^$', views.index, name='index'),                            #home page
    url(r'^register/$', views.register, name='register'),             #patient registration page
    url(r'^d_regis/$', views.d_regis, name='d_regis'),                #doctor registration page
    url(r'^logout/$', views.user_logout, name='logout'),              #logout link
    url(r'^feedback/$', views.feedback, name='feedback'),             #to give a feedback
    url(r'^my_app/$', views.my_app, name='my_app'),                   #to show the appointments
    url(r'^remove/$', views.remove, name='remove'),                   #to remove patient or doctor
    url(r'^my_profile/$', views.my_profile, name='my_profile'),       #to see own profile
    url(r'^s_feedback/$', views.s_feedback, name='s_feedback'),       #to see feedback
    url(r'^doctor_list/$', views.doctor_list, name='doctor_list'),    #to see doctor list
]